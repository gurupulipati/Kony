function addWidgetsfrmMain() {
    var button1048322716293 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716293",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716293_onClick_seq0,
        "skin": "btnNormal",
        "text": "PassLibrary available"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716294 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716294",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716294_onClick_seq0,
        "skin": "btnNormal",
        "text": "Create Pass library"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716295 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716295",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716295_onClick_seq0,
        "skin": "btnNormal",
        "text": "Add pass to the library with animation"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716296 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716296",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716296_onClick_seq0,
        "skin": "btnNormal",
        "text": "Contains pass"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716297 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716297",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716297_onClick_seq0,
        "skin": "btnNormal",
        "text": "Replace pass"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716298 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716298",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716298_onClick_seq0,
        "skin": "btnNormal",
        "text": "Remove pass"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716299 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716299",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716299_onClick_seq0,
        "skin": "btnNormal",
        "text": "Show passes"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button1048322716301 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1048322716301",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button1048322716301_onClick_seq0,
        "skin": "btnNormal",
        "text": "Pass with typeIdentifier and serialNumber"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button213050578140 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button213050578140",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button213050578140_onClick_seq0,
        "skin": "btnNormal",
        "text": "Add pass to the library without animation"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button2130505781280 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button2130505781280",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button2130505781280_onClick_seq0,
        "skin": "btnNormal",
        "text": "Add  multiple passes to the library"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button19708853624281 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624281",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624281_onClick_seq0,
        "skin": "btnNormal",
        "text": "Add Pass without .pkpass extension"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button19708853624282 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624282",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624282_onClick_seq0,
        "skin": "btnNormal",
        "text": "Invalid Content in .pkpass file"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button19708853624283 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624283",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624283_onClick_seq0,
        "skin": "btnNormal",
        "text": "ContainsPass after delete"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button19708853624284 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624284",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624284_onClick_seq0,
        "skin": "btnNormal",
        "text": "Passes Count in Passbook"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var button19708853624285 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624285",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624285_onClick_seq0,
        "skin": "btnNormal",
        "text": "Passes Count After Deleting All passes"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var hbox19708853624558 = new kony.ui.Box({
        "id": "hbox19708853624558",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 100,
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    var button19708853624286 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button19708853624286",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button19708853624286_onClick_seq0,
        "skin": "btnNormal",
        "text": "NextForm>>"
    }, {
        "containerWeight": 16,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_MIDDLE_RIGHT
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    hbox19708853624558.add(button19708853624286);
    var button13899216133 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button13899216133",
        "isVisible": true,
        "onClick": p2kwiet201735961558_button13899216133_onClick_seq0,
        "skin": "btnNormal",
        "text": "Open Pass in Passbook"
    }, {
        "containerWeight": 100,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "marginInPixel": true,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    frmMain.add(button1048322716293, button1048322716294, button1048322716295, button1048322716296, button1048322716297, button1048322716298, button1048322716299, button1048322716301, button213050578140, button2130505781280, button19708853624281, button19708853624282, button19708853624283, button19708853624284, button19708853624285, hbox19708853624558, button13899216133);
};

function frmMainGlobals() {
    frmMain = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmMain,
        "bounces": true,
        "enabledForIdleTimeout": false,
        "id": "frmMain",
        "needAppMenu": true,
        "skin": "frm"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "extendBottom": false,
        "extendTop": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": 100,
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "needsIndicatorDuringPostShow": true,
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "retainScrollPosition": false,
        "statusBarStyle": constants.STATUS_BAR_STYLE_DEFAULT,
        "titleBar": true,
        "titleBarConfig": {
            "renderTitleText": true,
            "prevFormTitle": false,
            "titleBarLeftSideView": "button",
            "labelLeftSideView": "Back",
            "titleBarRightSideView": "button",
            "labelRightSideView": "Edit"
        }
    });
    frmMain.info = {
        "kuid": "p2kwiet201735961558"
    };
};