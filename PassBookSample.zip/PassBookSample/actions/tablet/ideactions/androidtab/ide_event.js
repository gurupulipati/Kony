function p2kwiet201735961597_button1048322716293_onClick_seq0(eventobject) {
    if (isPassLibraryAvailable()) {
        alert("Pass Library available");
    } else {
        alert("Pass Library NOT available");
    }
};

function p2kwiet201735961597_button1048322716294_onClick_seq0(eventobject) {
    createPassLibrary.call(this);
};

function p2kwiet201735961597_button1048322716295_onClick_seq0(eventobject) {
    addPassToPassLibrary.call(this);
};

function p2kwiet201735961597_button1048322716296_onClick_seq0(eventobject) {
    libraryContainsPass.call(this);
};

function p2kwiet201735961597_button1048322716297_onClick_seq0(eventobject) {
    replacePassInLibrary.call(this);
};

function p2kwiet201735961597_button1048322716298_onClick_seq0(eventobject) {
    removePassFromLibrary.call(this);
};

function p2kwiet201735961597_button1048322716299_onClick_seq0(eventobject) {
    showPasses.call(this);
};

function p2kwiet201735961597_button1048322716301_onClick_seq0(eventobject) {
    getPassWithIdentifierAndSerialNumber.call(this);
};

function p2kwiet201735961597_button213050578140_onClick_seq0(eventobject) {
    addPassToPassLibraryWithoutAnimation.call(this);
};

function p2kwiet201735961597_button2130505781280_onClick_seq0(eventobject) {
    addPassesToPassLibrary.call(this);
};

function p2kwiet201735961597_button19708853624281_onClick_seq0(eventobject) {
    addPassToPassLibraryWOextension.call(this);
};

function p2kwiet201735961597_button19708853624282_onClick_seq0(eventobject) {
    addPassToPassLibraryInvalidContent.call(this);
};

function p2kwiet201735961597_button19708853624283_onClick_seq0(eventobject) {
    libraryContainsPassAfterDelete.call(this);
};

function p2kwiet201735961597_button19708853624284_onClick_seq0(eventobject) {
    passesCount.call(this);
};

function p2kwiet201735961597_button19708853624285_onClick_seq0(eventobject) {
    getZeroPasses.call(this);
};

function p2kwiet201735961597_button19708853624286_onClick_seq0(eventobject) {
    frmTwo.show();
};

function p2kwiet201735961623_button19708853624289_onClick_seq0(eventobject) {
    getPassAttributes.call(this);
};

function p2kwiet201735961623_button2130505781599_onClick_seq0(eventobject) {
    getLocalizedString.call(this);
};

function p2kwiet201735961623_button19708853624648_onClick_seq0(eventobject) {
    getLocalizedStringInvalidKey.call(this);
};

function p2kwiet201735961623_button1180790851141184_onClick_seq0(eventobject) {
    brdpass1.call(this);
};

function p2kwiet201735961623_button1180790851141187_onClick_seq0(eventobject) {
    Coupon.call(this);
};

function p2kwiet201735961623_button1180790851141190_onClick_seq0(eventobject) {
    event.call(this);
};

function p2kwiet201735961623_button1180790851141193_onClick_seq0(eventobject) {
    genRep.call(this);
};

function p2kwiet201735961623_button1180790851141185_onClick_seq0(eventobject) {
    brdpass2.call(this);
};

function p2kwiet201735961623_button1180790851141188_onClick_seq0(eventobject) {
    brdpasseEmpty.call(this);
};

function p2kwiet201735961623_button1180790851141191_onClick_seq0(eventobject) {
    freehugs.call(this);
};

function p2kwiet201735961623_button1180790851141194_onClick_seq0(eventobject) {
    strCard.call(this);
};

function p2kwiet201735961623_button1180790851141186_onClick_seq0(eventobject) {
    couI10N.call(this);
};

function p2kwiet201735961623_button1180790851141189_onClick_seq0(eventobject) {
    Coupon.call(this);
};

function p2kwiet201735961623_button1180790851141192_onClick_seq0(eventobject) {
    generic.call(this);
};

function p2kwiet201735961623_button1180790851141196_onClick_seq0(eventobject) {
    getFile.call(this);
};

function p2kwiet201735961623_button1180790851141197_onClick_seq0(eventobject) {
    addPassSavedFromURL.call(this);
};

function p2kwiet201735961623_button1180790851141199_onClick_seq0(eventobject) {
    addPassesToPassbook.call(this);
};