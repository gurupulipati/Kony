function p2kwiet201735961623_button1180790851141191_onClick_seq0(eventobject) {
    return freehugs.call(this);
}