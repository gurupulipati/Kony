function p2kwiet201735961597_button19708853624283_onClick_seq0(eventobject) {
    return libraryContainsPassAfterDelete.call(this);
}