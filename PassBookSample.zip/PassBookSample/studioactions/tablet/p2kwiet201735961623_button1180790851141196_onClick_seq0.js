function p2kwiet201735961623_button1180790851141196_onClick_seq0(eventobject) {
    return getFile.call(this);
}