function p2kwiet201735961623_button19708853624289_onClick_seq0(eventobject) {
    return getPassAttributes.call(this);
}