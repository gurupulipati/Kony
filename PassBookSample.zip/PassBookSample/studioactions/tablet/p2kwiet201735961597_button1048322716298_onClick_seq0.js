function p2kwiet201735961597_button1048322716298_onClick_seq0(eventobject) {
    return removePassFromLibrary.call(this);
}