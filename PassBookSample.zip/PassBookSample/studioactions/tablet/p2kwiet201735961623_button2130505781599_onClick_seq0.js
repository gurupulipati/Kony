function p2kwiet201735961623_button2130505781599_onClick_seq0(eventobject) {
    return getLocalizedString.call(this);
}