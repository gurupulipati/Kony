function p2kwiet201735961577_button1180105658141228_onClick_seq0(eventobject) {
    return getLocalizedStringBundleMissing.call(this);
}