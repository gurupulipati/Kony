function p2kwiet201735961558_button19708853624285_onClick_seq0(eventobject) {
    return getZeroPasses.call(this);
}