function p2kwiet201735961577_button19708853624648_onClick_seq0(eventobject) {
    return getLocalizedStringInvalidKey.call(this);
}