function p2kwiet201735961558_button1048322716293_onClick_seq0(eventobject) {
    if ((isPassLibraryAvailable())) {
        alert("Pass Library available");
    } else {
        alert("Pass Library NOT available");
    }
}