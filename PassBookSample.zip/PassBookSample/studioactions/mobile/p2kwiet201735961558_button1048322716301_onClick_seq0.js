function p2kwiet201735961558_button1048322716301_onClick_seq0(eventobject) {
    return getPassWithIdentifierAndSerialNumber.call(this);
}