function p2kwiet201735961558_button1048322716296_onClick_seq0(eventobject) {
    return libraryContainsPass.call(this);
}