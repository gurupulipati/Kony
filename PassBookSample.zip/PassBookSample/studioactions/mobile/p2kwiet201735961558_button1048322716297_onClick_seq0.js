function p2kwiet201735961558_button1048322716297_onClick_seq0(eventobject) {
    return replacePassInLibrary.call(this);
}