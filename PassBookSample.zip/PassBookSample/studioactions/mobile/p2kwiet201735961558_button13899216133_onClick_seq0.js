function p2kwiet201735961558_button13899216133_onClick_seq0(eventobject) {
    return openPassUsingPassURL.call(this);
}