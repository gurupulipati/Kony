//
//  FFI_Passbook.h
//  KLPassBook
//
//  Created by Amba on 25/02/14.
//  Copyright (c) 2014 Konylabs. All rights reserved.
//

#import "KonyPKPass.h"
#import "KonyPKPassLibrary.h"
#import "KonyPKAddPassesViewController.h"

#define FFI_PASSBOOK_SDK_VERSION @"1.0.0"

