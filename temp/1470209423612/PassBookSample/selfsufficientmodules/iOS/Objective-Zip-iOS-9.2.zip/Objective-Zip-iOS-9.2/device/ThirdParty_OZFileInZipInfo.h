#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_OZFileInZipInfo_symbols(JSContext*);
@protocol OZFileInZipInfoInstanceExports<JSExport>
@property (readonly,nonatomic) BOOL crypted;
@property (readonly,nonatomic) NSString * name;
@property (readonly,nonatomic) OZZipCompressionLevel level;
@property (readonly,nonatomic) NSUInteger crc32;
@property (readonly,nonatomic) unsigned long long length;
@property (readonly,nonatomic) NSDate * date;
@property (readonly,nonatomic) unsigned long long size;
@end
@protocol OZFileInZipInfoClassExports<JSExport>
@end
#pragma clang diagnostic pop