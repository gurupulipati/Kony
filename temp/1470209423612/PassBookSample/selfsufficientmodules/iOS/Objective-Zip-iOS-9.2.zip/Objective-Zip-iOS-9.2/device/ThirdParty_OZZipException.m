#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([OZZipException class], @protocol(OZZipExceptionInstanceExports));
	class_addProtocol([OZZipException class], @protocol(OZZipExceptionClassExports));
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &OZ_ERROR_NO_SUCH_FILE;
	if (p != NULL) context[@"OZ_ERROR_NO_SUCH_FILE"] = @(OZ_ERROR_NO_SUCH_FILE);
}
void load_ThirdParty_OZZipException_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
