#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_OZZipFile_symbols(JSContext*);
@protocol OZZipFileInstanceExports<JSExport>
@property (readonly,nonatomic) BOOL legacy32BitMode;
@property (readonly,nonatomic) OZZipFileMode mode;
@property (readonly,nonatomic) NSString * fileName;
@end
@protocol OZZipFileClassExports<JSExport>
@end
#pragma clang diagnostic pop