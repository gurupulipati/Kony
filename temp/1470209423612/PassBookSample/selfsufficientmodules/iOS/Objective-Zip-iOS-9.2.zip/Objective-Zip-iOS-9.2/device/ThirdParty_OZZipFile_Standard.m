#import <objc/runtime.h>
#import "allincludes.h"
#import "ClassExtension.h"
#import "PointerSupport.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation OZZipFile (OZZipFileStandardCategoryExports)
-(id) jsinitWithFileName: (NSString *) fileName mode: (OZZipFileMode) mode 
{
	id resultVal__;
	resultVal__ = [[self initWithFileName: fileName mode: mode ] autorelease];
	return resultVal__;
}
-(id) jsinitWithFileName: (NSString *) fileName mode: (OZZipFileMode) mode legacy32BitMode: (BOOL) legacy32BitMode 
{
	id resultVal__;
	resultVal__ = [[self initWithFileName: fileName mode: mode legacy32BitMode: legacy32BitMode ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([OZZipFile class], @protocol(OZZipFileStandardCategoryInstanceExports));
	class_addProtocol([OZZipFile class], @protocol(OZZipFileStandardCategoryClassExports));
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_ThirdParty_OZZipFile_Standard_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
