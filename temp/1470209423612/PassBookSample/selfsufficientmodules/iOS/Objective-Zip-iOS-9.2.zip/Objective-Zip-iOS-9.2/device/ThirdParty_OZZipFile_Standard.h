#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_ThirdParty_OZZipFile_Standard_symbols(JSContext*);
@protocol OZZipFileStandardCategoryInstanceExports<JSExport>
JSExportAs(initWithFileNameMode,
-(id) jsinitWithFileName: (NSString *) fileName mode: (OZZipFileMode) mode );
-(OZZipReadStream *) readCurrentFileInZipWithPassword: (NSString *) password ;
-(OZFileInZipInfo *) getCurrentFileInZipInfo;
-(NSUInteger) numFilesInZip;
-(OZZipWriteStream *) writeFileInZipWithName: (NSString *) fileNameInZip fileDate: (NSDate *) fileDate compressionLevel: (OZZipCompressionLevel) compressionLevel password: (NSString *) password crc32: (NSUInteger) crc32 ;
JSExportAs(initWithFileNameModeLegacy32BitMode,
-(id) jsinitWithFileName: (NSString *) fileName mode: (OZZipFileMode) mode legacy32BitMode: (BOOL) legacy32BitMode );
-(BOOL) goToNextFileInZip;
-(OZZipWriteStream *) writeFileInZipWithName: (NSString *) fileNameInZip fileDate: (NSDate *) fileDate compressionLevel: (OZZipCompressionLevel) compressionLevel ;
-(BOOL) locateFileInZip: (NSString *) fileNameInZip ;
-(NSArray *) listFileInZipInfos;
-(OZZipWriteStream *) writeFileInZipWithName: (NSString *) fileNameInZip compressionLevel: (OZZipCompressionLevel) compressionLevel ;
-(void) close;
-(void) goToFirstFileInZip;
-(OZZipReadStream *) readCurrentFileInZip;
@end
@protocol OZZipFileStandardCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop